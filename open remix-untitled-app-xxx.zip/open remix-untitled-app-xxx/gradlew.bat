@echo off
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle is not installed. Install Gradle or use the included GitHub Actions workflow. 1>&2
  exit /b 127
)
gradle %*
