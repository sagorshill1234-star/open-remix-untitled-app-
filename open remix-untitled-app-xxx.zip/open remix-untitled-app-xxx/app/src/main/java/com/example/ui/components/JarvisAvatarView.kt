package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald

@Composable
fun JarvisAvatarView(
    nickname: String = "অহন",
    isListening: Boolean = false,
    isSpeaking: Boolean = false,
    isOfflineMode: Boolean = false,
    avatarSize: Dp = 130.dp,
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "avatar_anim")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening || isSpeaking) 1.08f else 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isListening) 600 else 1800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isListening) 4000 else 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val ringBrush = Brush.sweepGradient(
        listOf(
            CyberCyan,
            CyberEmerald,
            CyberAmber,
            Color.Transparent,
            CyberCyan
        )
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(8.dp)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(avatarSize + 30.dp)
                .scale(pulseScale)
                .clickable { onClick() }
                .testTag("jarvis_avatar_box")
        ) {
            // Rotating Holographic Cyber Halo Ring
            Box(
                modifier = Modifier
                    .size(avatarSize + 22.dp)
                    .rotate(rotationAngle)
                    .border(
                        width = 2.5.dp,
                        brush = ringBrush,
                        shape = CircleShape
                    )
            )

            // Inner Pulsing Ambient Glow
            Box(
                modifier = Modifier
                    .size(avatarSize + 10.dp)
                    .background(
                        color = if (isListening) CyberCyan.copy(alpha = 0.25f)
                        else if (isSpeaking) CyberAmber.copy(alpha = 0.25f)
                        else CyberCyan.copy(alpha = 0.12f),
                        shape = CircleShape
                    )
            )

            // 3D Avatar Image
            Image(
                painter = painterResource(id = R.drawable.img_jarvis_avatar),
                contentDescription = "$nickname - 3D AI Companion",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(avatarSize)
                    .clip(CircleShape)
                    .border(
                        width = 2.dp,
                        color = if (isListening) CyberCyan else CyberAmber,
                        shape = CircleShape
                    )
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Status Badge
        val statusBg = if (isOfflineMode) CyberAmber.copy(alpha = 0.2f) else CyberCyan.copy(alpha = 0.2f)
        val statusColor = if (isOfflineMode) CyberAmber else CyberCyan
        val statusText = when {
            isListening -> "🎙️ শুনছি... বলুন!"
            isSpeaking -> "🔊 কথা বলছি..."
            isOfflineMode -> "📡 অফলাইন স্মার্ট মোড"
            else -> "✨ Gemini AI অনলাইন"
        }

        Box(
            modifier = Modifier
                .background(statusBg, RoundedCornerShape(12.dp))
                .border(1.dp, statusColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                .padding(horizontal = 10.dp, vertical = 3.dp)
        ) {
            Text(
                text = "$nickname • $statusText",
                color = statusColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
