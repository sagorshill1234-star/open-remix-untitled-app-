package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import com.example.data.entity.ChatMessageEntity
import com.example.data.entity.MedicineReminderEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllMessagesFlow(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clearAllMessages()
}

@Dao
interface MedicineDao {
    @Query("SELECT * FROM medicine_reminders ORDER BY timeHour ASC, timeMinute ASC")
    fun getAllRemindersFlow(): Flow<List<MedicineReminderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: MedicineReminderEntity): Long

    @Update
    suspend fun updateReminder(reminder: MedicineReminderEntity)

    @Delete
    suspend fun deleteReminder(reminder: MedicineReminderEntity)

    @Query("UPDATE medicine_reminders SET isTakenToday = :taken WHERE id = :id")
    suspend fun setTakenStatus(id: Long, taken: Boolean)
}

@Database(entities = [ChatMessageEntity::class, MedicineReminderEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun medicineDao(): MedicineDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "jarvis_local_encrypted.db"
                ).fallbackToDestructiveMigration(dropAllTables = true).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
