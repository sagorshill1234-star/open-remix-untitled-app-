package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberCyan = Color(0xFF00E5FF)
val CyberDarkNavy = Color(0xFF070B14)
val CyberDarkSurface = Color(0xFF0D1424)
val CyberCard = Color(0xFF131E33)
val CyberCardBorder = Color(0xFF1E2E4E)
val CyberAmber = Color(0xFFFFB703)
val CyberEmerald = Color(0xFF10B981)
val CyberPink = Color(0xFFFF3366)
val CyberPurple = Color(0xFFA855F7)
val CyberTextPrimary = Color(0xFFF8FAFC)
val CyberTextSecondary = Color(0xFF94A3B8)
val CyberAccentGlow = Color(0x3300E5FF)
