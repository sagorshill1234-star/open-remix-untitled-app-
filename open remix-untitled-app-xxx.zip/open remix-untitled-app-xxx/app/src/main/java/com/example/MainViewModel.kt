package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.api.ContentItem
import com.example.data.api.GeminiClient
import com.example.data.api.GeminiRequest
import com.example.data.api.OfflineAiEngine
import com.example.data.api.PartItem
import com.example.data.entity.ChatMessageEntity
import com.example.data.entity.MedicineReminderEntity
import com.example.service.NotificationHelper
import com.example.service.PhoneCareManager
import com.example.service.VoiceInteractionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppPersona(val displayName: String, val description: String) {
    COMPANION("অহন (মিষ্টি বন্ধু ও কেয়ারার)", "গার্লফ্রেন্ডের মতো সহানুভূতিশীল, যত্নবান ও আনন্দদায়ক"),
    CYBER_JARVIS("সাইবার জার্ভিস (Jarvis Protocol)", "প্রফেশনাল, টেকনোলজিক্যাল ও ক্ষিপ্রগতির অ্যাসিস্ট্যান্ট"),
    HEALTH_EXPERT("স্বাস্থ্য ও ড্রাগ কনসালট্যান্ট", "রোগ প্রতিরোধ ও সঠিক ঔষধ সেবনের বিষয়ে বিশেষ গুরুত্ব দেয়")
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val chatDao = db.chatDao()
    private val medicineDao = db.medicineDao()

    val phoneCareManager = PhoneCareManager(application)
    val authManager = com.example.service.AuthManager(application)
    val firestoreRepo = com.example.data.repository.FirestoreSyncRepository(application)

    // Voice Interaction
    lateinit var voiceManager: VoiceInteractionManager

    // UI States
    val chatMessages: StateFlow<List<ChatMessageEntity>> = chatDao.getAllMessagesFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val medicineReminders: StateFlow<List<MedicineReminderEntity>> = medicineDao.getAllRemindersFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _nickname = MutableStateFlow("অহন")
    val nickname: StateFlow<String> = _nickname.asStateFlow()

    private val _isOfflineMode = MutableStateFlow(false)
    val isOfflineMode: StateFlow<Boolean> = _isOfflineMode.asStateFlow()

    private val _isVoiceTtsEnabled = MutableStateFlow(true)
    val isVoiceTtsEnabled: StateFlow<Boolean> = _isVoiceTtsEnabled.asStateFlow()

    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _selectedPersona = MutableStateFlow(AppPersona.COMPANION)
    val selectedPersona: StateFlow<AppPersona> = _selectedPersona.asStateFlow()

    private val _boostSuccessMessage = MutableStateFlow<String?>(null)
    val boostSuccessMessage: StateFlow<String?> = _boostSuccessMessage.asStateFlow()

    init {
        NotificationHelper.initNotificationChannels(application)
        initVoice()
        startAutoRamBoostTicker()
        seedInitialMessagesIfEmpty()
    }

    private fun initVoice() {
        voiceManager = VoiceInteractionManager(getApplication()) { recognizedText ->
            if (recognizedText.isNotBlank()) {
                sendMessage(recognizedText)
            }
        }
    }

    private fun seedInitialMessagesIfEmpty() {
        viewModelScope.launch(Dispatchers.IO) {
            val count = chatDao.getAllMessagesFlow()
            // If empty, add a welcoming message from Ahon / Jarvis
            launch {
                delay(300)
                if (chatMessages.value.isEmpty()) {
                    chatDao.insertMessage(
                        ChatMessageEntity(
                            sender = "AI",
                            content = "👋 হ্যালো! আমি আপনার ব্যক্তিগত এআই সঙ্গী ও জার্ভিস 'অহন' (Ahon)।\n" +
                                    "আমি আপনার ফোনের ব্যাটারি হেলথ রক্ষা, ৩ ঘণ্টা পর পর র‍্যাম বুস্ট, রোগ প্রতিরোধ পরামর্শ ও সঠিক ঔষধ সেবনের সময় মনে করিয়ে দিতে প্রস্তুত!\n" +
                                    "আমাকে যেকোনো প্রশ্ন করুন বা ভয়েসে কথা বলুন। ❤️",
                            isOfflineMode = false
                        )
                    )
                }
            }
        }
    }

    private fun startAutoRamBoostTicker() {
        viewModelScope.launch(Dispatchers.Default) {
            while (true) {
                delay(60_000L) // every minute
                val ram = phoneCareManager.ramInfo.value
                if (ram.isAutoBoostEnabled) {
                    val passedMinutes = ((System.currentTimeMillis() - ram.lastBoostTimeMillis) / (60 * 1000L)).toInt()
                    if (passedMinutes >= 180) { // 3 hours
                        viewModelScope.launch(Dispatchers.Main) {
                            val freed = phoneCareManager.boostRam()
                            NotificationHelper.showBatteryAlertNotification(
                                getApplication(),
                                "⚡ অটো র‍্যাম বুস্ট সম্পন্ন!",
                                "৩ ঘণ্টা পূর্ণ হওয়ায় ${freed}MB ব্যাকগ্রাউন্ড ক্যাশ ক্লিয়ার করা হয়েছে।"
                            )
                        }
                    }
                }
            }
        }
    }

    fun setNickname(name: String) {
        if (name.isNotBlank()) {
            _nickname.value = name.trim()
        }
    }

    fun setOfflineMode(enabled: Boolean) {
        _isOfflineMode.value = enabled
    }

    fun setVoiceTtsEnabled(enabled: Boolean) {
        _isVoiceTtsEnabled.value = enabled
    }

    fun setDarkMode(dark: Boolean) {
        _isDarkMode.value = dark
    }

    fun setPersona(persona: AppPersona) {
        _selectedPersona.value = persona
    }

    fun clearChat() {
        viewModelScope.launch(Dispatchers.IO) {
            chatDao.clearAllMessages()
        }
    }

    fun triggerRamBoost() {
        val freed = phoneCareManager.boostRam()
        _boostSuccessMessage.value = "⚡ ${freed}MB RAM ক্লিয়ার হয়েছে! ফোন এখন সুপার ফাস্ট।"
        voiceManager.speak("আপনার ফোনের RAM অপ্টিমাইজ করা হয়েছে।", _isVoiceTtsEnabled.value)
        viewModelScope.launch {
            delay(3500)
            _boostSuccessMessage.value = null
        }
    }

    fun sendMessage(userText: String) {
        val trimmed = userText.trim()
        if (trimmed.isEmpty()) return

        viewModelScope.launch {
            // Save user message to Room
            val userMsg = ChatMessageEntity(
                sender = "USER",
                content = trimmed,
                isOfflineMode = _isOfflineMode.value
            )
            chatDao.insertMessage(userMsg)
            firestoreRepo.syncChatMessage(userMsg)

            // Check if Offline Mode or Gemini API
            if (_isOfflineMode.value) {
                processWithOfflineEngine(trimmed)
            } else {
                val apiKey = GeminiClient.getApiKey()
                if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                    // Fallback to offline engine seamlessly if API key not provided yet
                    processWithOfflineEngine(trimmed, fallbackNotice = true)
                } else {
                    processWithGemini(trimmed, apiKey)
                }
            }
        }
    }

    private suspend fun processWithOfflineEngine(input: String, fallbackNotice: Boolean = false) {
        _isGenerating.value = true
        delay(400) // gentle typing feel
        val parsed = OfflineAiEngine.processQuery(input, _nickname.value)

        var reply = parsed.textResponse
        if (fallbackNotice) {
            reply = "✨ [অফলাইন ইন্টেলিজেন্স]: $reply"
        }

        // Perform hardware action if requested
        if (parsed.shouldExecuteAction) {
            when (parsed.intent) {
                OfflineAiEngine.IntentType.BOOST_RAM -> {
                    phoneCareManager.boostRam()
                }
                OfflineAiEngine.IntentType.OPEN_SETTINGS -> {
                    phoneCareManager.openBatterySettings()
                }
                else -> {}
            }
        }

        val aiMsg = ChatMessageEntity(
            sender = "AI",
            content = reply,
            isOfflineMode = true
        )
        chatDao.insertMessage(aiMsg)
        firestoreRepo.syncChatMessage(aiMsg)
        _isGenerating.value = false
        voiceManager.speak(reply, _isVoiceTtsEnabled.value)
    }

    private suspend fun processWithGemini(input: String, apiKey: String) {
        _isGenerating.value = true
        val persona = _selectedPersona.value
        val nickname = _nickname.value

        val systemPrompt = """
            You are $nickname, a caring, ultra-smart AI companion and personal Jarvis.
            Persona: ${persona.displayName} - ${persona.description}.
            Language: Fluent Bengali (বাংলা) and English. Respond in the language used by the user (primarily Bengali).
            Be warm, empathetic, caring like a close companion or girlfriend when asked, and highly knowledgeable.
            Capabilities:
            - Phone Care: Smart charging (unplug at 80%, charge at 20%), heat protection, RAM optimization.
            - Health & Disease Prevention: Disease prevention advice, symptom triage, detailed safe medicine dosage, before/after meals timing, and safety disclaimers to consult a registered doctor for severe conditions.
            - Keep responses clear, beautifully formatted with emojis, concise, and helpful.
        """.trimIndent()

        try {
            val request = GeminiRequest(
                contents = listOf(
                    ContentItem(
                        parts = listOf(PartItem(text = input)),
                        role = "user"
                    )
                ),
                systemInstruction = ContentItem(
                    parts = listOf(PartItem(text = systemPrompt))
                )
            )

            val response = GeminiClient.service.generateContent(apiKey, request)
            val replyText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: "আমি দুঃখিত, উত্তর তৈরি করতে পারিনি। অনুগ্রহ করে আবার চেষ্টা করুন।"

            val aiMsg = ChatMessageEntity(
                sender = "AI",
                content = replyText,
                isOfflineMode = false
            )
            chatDao.insertMessage(aiMsg)
            firestoreRepo.syncChatMessage(aiMsg)
            voiceManager.speak(replyText, _isVoiceTtsEnabled.value)
        } catch (e: Exception) {
            // If network fails, gracefully fall back to Offline Engine
            val offlineFallback = OfflineAiEngine.processQuery(input, nickname)
            val fallbackText = "⚠️ [অফলাইন ব্যাকআপ]: ইন্টারনেট সংযোগে সমস্যা হয়েছে।\n${offlineFallback.textResponse}"
            val fallbackMsg = ChatMessageEntity(
                sender = "AI",
                content = fallbackText,
                isOfflineMode = true
            )
            chatDao.insertMessage(fallbackMsg)
            firestoreRepo.syncChatMessage(fallbackMsg)
            voiceManager.speak(offlineFallback.textResponse, _isVoiceTtsEnabled.value)
        } finally {
            _isGenerating.value = false
        }
    }

    // Medicine Reminders
    fun addMedicineReminder(
        name: String,
        dosage: String,
        hour: Int,
        minute: Int,
        mealTiming: String,
        category: String,
        notes: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val reminder = MedicineReminderEntity(
                medicineName = name,
                dosage = dosage,
                timeHour = hour,
                timeMinute = minute,
                mealTiming = mealTiming,
                category = category,
                notes = notes
            )
            val newId = medicineDao.insertReminder(reminder)
            firestoreRepo.syncMedicineReminder(reminder.copy(id = newId))
            NotificationHelper.showMedicineReminderNotification(
                getApplication(),
                name,
                dosage,
                mealTiming
            )
        }
    }

    fun toggleMedicineTaken(id: Long, taken: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            medicineDao.setTakenStatus(id, taken)
        }
    }

    fun deleteMedicine(reminder: MedicineReminderEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            medicineDao.deleteReminder(reminder)
            firestoreRepo.deleteMedicineReminder(reminder.id)
        }
    }

    override fun onCleared() {
        super.onCleared()
        phoneCareManager.unregister()
        voiceManager.shutdown()
    }
}
