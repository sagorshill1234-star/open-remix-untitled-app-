package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "medicine_reminders")
data class MedicineReminderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val medicineName: String,
    val dosage: String, // e.g. "১টি ট্যাবলেট", "২ চামচ"
    val timeHour: Int, // 0-23
    val timeMinute: Int, // 0-59
    val mealTiming: String, // "খাওয়ার আগে" (Before Meal) or "খাওয়ার পরে" (After Meal)
    val category: String = "ট্যাবলেট", // ট্যাবলেট, ক্যাপসুল, সিরাপ, ইনজেকশন
    val notes: String = "",
    val isActive: Boolean = true,
    val isTakenToday: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
