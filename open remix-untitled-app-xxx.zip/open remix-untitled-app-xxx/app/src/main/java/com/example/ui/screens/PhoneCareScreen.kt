package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MainViewModel
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberDarkNavy
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberPink
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary

@Composable
fun PhoneCareScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val phoneCare = viewModel.phoneCareManager
    val batteryInfo by phoneCare.batteryInfo.collectAsState()
    val ramInfo by phoneCare.ramInfo.collectAsState()
    val boostMsg by viewModel.boostSuccessMessage.collectAsState()

    val totalRamMb = ramInfo.totalRamBytes / (1024 * 1024)
    val availRamMb = ramInfo.availableRamBytes / (1024 * 1024)
    val usedRamMb = totalRamMb - availRamMb

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberDarkNavy)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Title
        Text(
            text = "⚡ ফোন কেয়ার ও ব্যাটারি গার্ড",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = CyberCyan
        )
        Text(
            text = "রিয়েলটাইম ব্যাটারি সুরক্ষা ও ৩-ঘণ্টা অটো RAM বুস্টার",
            fontSize = 12.sp,
            color = CyberTextSecondary
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Battery Care Card
        Card(
            modifier = Modifier.fillMaxWidth().testTag("battery_care_card"),
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ব্যাটারি স্ট্যাটাস",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = CyberTextPrimary
                        )
                        Text(
                            text = if (batteryInfo.isCharging) "⚡ চার্জ হচ্ছে" else "🔋 ডিসচার্জিং",
                            fontSize = 12.sp,
                            color = if (batteryInfo.isCharging) CyberEmerald else CyberAmber
                        )
                    }

                    // Battery Circular Gauge
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(70.dp)
                    ) {
                        CircularProgressIndicator(
                            progress = { batteryInfo.percentage / 100f },
                            modifier = Modifier.fillMaxSize(),
                            color = if (batteryInfo.percentage <= 20) CyberPink
                            else if (batteryInfo.percentage >= 80) CyberCyan
                            else CyberEmerald,
                            strokeWidth = 6.dp,
                            trackColor = CyberCardBorder
                        )
                        Text(
                            text = "${batteryInfo.percentage}%",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = CyberTextPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Battery Telemetry Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    CareMetricItem(
                        icon = Icons.Default.Thermostat,
                        label = "তাপমাত্রা",
                        value = "${batteryInfo.temperatureCelsius}°C",
                        tint = if (batteryInfo.temperatureCelsius > 40f) CyberPink else CyberAmber
                    )
                    CareMetricItem(
                        icon = Icons.Default.Bolt,
                        label = "ভোল্টেজ",
                        value = "${batteryInfo.voltageMilliVolts} mV",
                        tint = CyberCyan
                    )
                    CareMetricItem(
                        icon = Icons.Default.BatteryAlert,
                        label = "স্বাস্থ্য",
                        value = batteryInfo.healthStatus,
                        tint = CyberEmerald
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Smart Charge Advice Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(CyberCyan.copy(alpha = 0.12f))
                        .border(1.dp, CyberCyan.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = batteryInfo.smartChargeAdvice,
                        color = CyberCyan,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // RAM & Memory Booster Card
        Card(
            modifier = Modifier.fillMaxWidth().testTag("ram_boost_card"),
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Memory,
                            contentDescription = "RAM",
                            tint = CyberCyan,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "RAM মেমোরি বুস্টার",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = CyberTextPrimary
                        )
                    }

                    Text(
                        text = "${ramInfo.usedRamPercent}% ব্যবহৃত",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (ramInfo.usedRamPercent > 75) CyberPink else CyberEmerald
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LinearProgressIndicator(
                    progress = { ramInfo.usedRamPercent / 100f },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = if (ramInfo.usedRamPercent > 75) CyberPink else CyberCyan,
                    trackColor = CyberCardBorder
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "ব্যবহার: ${usedRamMb}MB",
                        fontSize = 12.sp,
                        color = CyberTextSecondary
                    )
                    Text(
                        text = "ফ্রি মেমোরি: ${availRamMb}MB / ${totalRamMb}MB",
                        fontSize = 12.sp,
                        color = CyberTextSecondary
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Auto 3-Hour RAM Boost Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(CyberDarkNavy)
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "অটো ৩ ঘন্টা পর পর RAM বুস্ট",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = CyberTextPrimary
                        )
                        Text(
                            text = if (ramInfo.isAutoBoostEnabled) "সক্রিয় রয়েছে (স্মার্ট ব্যাকগ্রাউন্ড ট্রিম)" else "বন্ধ রয়েছে",
                            fontSize = 11.sp,
                            color = if (ramInfo.isAutoBoostEnabled) CyberEmerald else CyberTextSecondary
                        )
                    }

                    Switch(
                        checked = ramInfo.isAutoBoostEnabled,
                        onCheckedChange = { phoneCare.setAutoBoostEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CyberDarkNavy,
                            checkedTrackColor = CyberCyan,
                            uncheckedThumbColor = CyberTextSecondary,
                            uncheckedTrackColor = CyberCardBorder
                        ),
                        modifier = Modifier.testTag("auto_boost_switch")
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Boost Action Button
                Button(
                    onClick = { viewModel.triggerRamBoost() },
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("boost_ram_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = "Boost",
                        tint = CyberDarkNavy
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "এখনই RAM বুস্ট ও অপ্টিমাইজ করুন",
                        color = CyberDarkNavy,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                AnimatedVisibility(
                    visible = boostMsg != null,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    boostMsg?.let { msg ->
                        Text(
                            text = msg,
                            color = CyberEmerald,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Phone Settings & Shortcut Mode
        Text(
            text = "⚙️ ফোন সেটিংস শর্টকাট মোড",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = CyberTextPrimary
        )
        Text(
            text = "এক ট্যাপেই ফোনের গুরুত্বপূর্ণ সিস্টেম অপশনে প্রবেশ করুন",
            fontSize = 12.sp,
            color = CyberTextSecondary
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ShortcutCard(
                icon = Icons.Default.BatteryChargingFull,
                title = "ব্যাটারি সেটিংস",
                subtitle = "পাওয়ার সেভার",
                modifier = Modifier.weight(1f),
                onClick = { phoneCare.openBatterySettings() }
            )
            ShortcutCard(
                icon = Icons.Default.Wifi,
                title = "Wi-Fi সেটিংস",
                subtitle = "নেটওয়ার্ক মোড",
                modifier = Modifier.weight(1f),
                onClick = { phoneCare.openWifiSettings() }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ShortcutCard(
                icon = Icons.Default.BrightnessMedium,
                title = "ডিসপ্লে সেটিংস",
                subtitle = "ডার্ক মোড ও ব্রাইটনেস",
                modifier = Modifier.weight(1f),
                onClick = { phoneCare.openDisplaySettings() }
            )
            ShortcutCard(
                icon = Icons.AutoMirrored.Filled.VolumeUp,
                title = "সাউন্ড সেটিংস",
                subtitle = "রিংটোন ও ভলিউম",
                modifier = Modifier.weight(1f),
                onClick = { phoneCare.openSoundSettings() }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ShortcutCard(
                icon = Icons.Default.NotificationsActive,
                title = "নোটিফিকেশন",
                subtitle = "অ্যাপ পারমিশন",
                modifier = Modifier.weight(1f),
                onClick = { phoneCare.openNotificationSettings() }
            )
            ShortcutCard(
                icon = Icons.Default.FlashlightOn,
                title = "টর্চ / ফ্ল্যাশ",
                subtitle = "অন/অফ টগল",
                modifier = Modifier.weight(1f),
                onClick = { phoneCare.toggleFlashlight() }
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun CareMetricItem(
    icon: ImageVector,
    label: String,
    value: String,
    tint: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = CyberTextPrimary
        )
        Text(
            text = label,
            fontSize = 10.sp,
            color = CyberTextSecondary
        )
    }
}

@Composable
fun ShortcutCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clickable { onClick() }
            .testTag("shortcut_${title.hashCode()}"),
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(CyberCyan.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = CyberCyan,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = CyberTextPrimary
                )
                Text(
                    text = subtitle,
                    fontSize = 10.sp,
                    color = CyberTextSecondary
                )
            }
        }
    }
}
