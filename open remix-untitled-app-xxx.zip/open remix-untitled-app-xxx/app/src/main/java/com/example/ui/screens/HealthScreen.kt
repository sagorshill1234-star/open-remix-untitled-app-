package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Healing
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MainViewModel
import com.example.data.entity.MedicineReminderEntity
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberDarkNavy
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberPink
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary

@Composable
fun HealthScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val reminders by viewModel.medicineReminders.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }
    var showAddDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var quickAdviceResult by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CyberDarkNavy)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "🩺 স্বাস্থ্য ও ঔষধ কেয়ার",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyan
                    )
                    Text(
                        text = "রোগ প্রতিরোধ নির্দেশিকা ও সময়মতো ঔষধ সেবন",
                        fontSize = 12.sp,
                        color = CyberTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Navigation Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = CyberCard,
                contentColor = CyberCyan,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = CyberCyan
                    )
                },
                modifier = Modifier.clip(RoundedCornerShape(12.dp))
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("⏰ ঔষধের রিমাইন্ডার", fontWeight = FontWeight.SemiBold, fontSize = 13.sp) },
                    modifier = Modifier.testTag("tab_medicine_reminders")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("🛡️ রোগ প্রতিরোধ ও ঔষধ গাইড", fontWeight = FontWeight.SemiBold, fontSize = 13.sp) },
                    modifier = Modifier.testTag("tab_disease_prevention")
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (selectedTab == 0) {
                // Medicine Reminders Tab
                MedicineRemindersContent(
                    reminders = reminders,
                    onToggleTaken = { id, taken -> viewModel.toggleMedicineTaken(id, taken) },
                    onDelete = { viewModel.deleteMedicine(it) },
                    onAddNew = { showAddDialog = true }
                )
            } else {
                // Disease Prevention & Drug Advisor Tab
                DiseasePreventionContent(
                    searchQuery = searchQuery,
                    onSearchQueryChange = { searchQuery = it },
                    quickAdviceResult = quickAdviceResult,
                    onPerformSearch = { q ->
                        viewModel.sendMessage("আমাকে এই ঔষধ বা রোগ সম্পর্কে সঠিক নিয়ম ও পরামর্শ দাও: $q")
                        quickAdviceResult = "অহন আপনার প্রশ্ন চ্যাটে বিশ্লেষণ করছে..."
                    }
                )
            }
        }

        // Floating Action Button to Add Medicine Reminder
        if (selectedTab == 0) {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = CyberCyan,
                contentColor = CyberDarkNavy,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(20.dp)
                    .testTag("add_medicine_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Medicine")
            }
        }
    }

    if (showAddDialog) {
        AddMedicineDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { name, dosage, hour, minute, meal, cat, notes ->
                viewModel.addMedicineReminder(name, dosage, hour, minute, meal, cat, notes)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun MedicineRemindersContent(
    reminders: List<MedicineReminderEntity>,
    onToggleTaken: (Long, Boolean) -> Unit,
    onDelete: (MedicineReminderEntity) -> Unit,
    onAddNew: () -> Unit
) {
    if (reminders.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Medication,
                    contentDescription = null,
                    tint = CyberCyan.copy(alpha = 0.5f),
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "কোনো ঔষধের রিমাইন্ডার নেই",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberTextPrimary
                )
                Text(
                    text = "সময়মতো ঔষধ খেতে নিচে '+' বাটনে ট্যাপ করুন",
                    fontSize = 12.sp,
                    color = CyberTextSecondary
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onAddNew,
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("empty_add_medicine_button")
                ) {
                    Text("ঔষধ যোগ করুন", color = CyberDarkNavy, fontWeight = FontWeight.Bold)
                }
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(reminders) { item ->
                MedicineReminderCard(
                    item = item,
                    onToggleTaken = { onToggleTaken(item.id, !item.isTakenToday) },
                    onDelete = { onDelete(item) }
                )
            }
            item { Spacer(modifier = Modifier.height(70.dp)) }
        }
    }
}

@Composable
fun MedicineReminderCard(
    item: MedicineReminderEntity,
    onToggleTaken: () -> Unit,
    onDelete: () -> Unit
) {
    val formattedTime = String.format("%02d:%02d", item.timeHour, item.timeMinute)
    val amPm = if (item.timeHour >= 12) "PM" else "AM"

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("medicine_card_${item.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (item.isTakenToday) CyberCard.copy(alpha = 0.6f) else CyberCard
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (item.isTakenToday) CyberEmerald.copy(alpha = 0.4f) else CyberCardBorder
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Checkbox for taken
            IconButton(
                onClick = onToggleTaken,
                modifier = Modifier.size(36.dp).testTag("take_btn_${item.id}")
            ) {
                Icon(
                    imageVector = if (item.isTakenToday) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                    contentDescription = "Taken status",
                    tint = if (item.isTakenToday) CyberEmerald else CyberCyan,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = item.medicineName,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (item.isTakenToday) CyberTextSecondary else CyberTextPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .background(CyberCyan.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = item.mealTiming,
                            fontSize = 11.sp,
                            color = CyberCyan
                        )
                    }
                }

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = "মাত্রা: ${item.dosage} • ধরণ: ${item.category}",
                    fontSize = 12.sp,
                    color = CyberTextSecondary
                )

                if (item.notes.isNotBlank()) {
                    Text(
                        text = "নোট: ${item.notes}",
                        fontSize = 11.sp,
                        color = CyberAmber
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "$formattedTime $amPm",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberAmber
                )
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(30.dp).testTag("delete_med_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Delete",
                        tint = CyberPink,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun DiseasePreventionContent(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    quickAdviceResult: String?,
    onPerformSearch: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            // Search Bar for Medicines / Disease query
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = {
                        Text("ঔষধ বা রোগের নাম লিখুন (যেমন: নাপা, ডেঙ্গু)...", fontSize = 12.sp, color = CyberTextSecondary)
                    },
                    modifier = Modifier.weight(1f).testTag("health_search_field"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = CyberCardBorder,
                        focusedContainerColor = CyberCard,
                        unfocusedContainerColor = CyberCard,
                        focusedTextColor = CyberTextPrimary,
                        unfocusedTextColor = CyberTextPrimary
                    ),
                    maxLines = 1
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        if (searchQuery.isNotBlank()) {
                            onPerformSearch(searchQuery)
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(CyberCyan)
                        .testTag("health_search_btn")
                ) {
                    Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = CyberDarkNavy)
                }
            }
        }

        if (quickAdviceResult != null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(CyberCyan.copy(alpha = 0.12f))
                        .border(1.dp, CyberCyan.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Text(text = quickAdviceResult, color = CyberCyan, fontSize = 13.sp)
                }
            }
        }

        item {
            Text(
                text = "🛡️ প্রধান রোগ প্রতিরোধ গাইডলাইন",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = CyberTextPrimary
            )
        }

        item {
            PreventionGuideCard(
                title = "জ্বর ও ভাইরাল সংক্রমণ প্রতিরোধ",
                points = listOf(
                    "প্যারাসিটামল ৫০০মিগ্রা শুধুমাত্র ভরা পেটে ৬-৮ ঘণ্টা পর পর খাওয়া নিরাপদ।",
                    "খালি পেটে ব্যথানাশক ঔষধ কখনই খাবেন না।",
                    "জ্বর ৩ দিনের বেশি থাকলে রক্ত পরীক্ষা ও ডাক্তারের পরামর্শ নেওয়া জরুরি।"
                ),
                color = CyberCyan
            )
        }

        item {
            PreventionGuideCard(
                title = "গ্যাস্ট্রিক ও এসিডিটি নিরাময়ের নিয়ম",
                points = listOf(
                    "ওমেপ্রাজল/ইসোমিপ্রাজল সকালে নাস্তার ৩০ মিনিট আগে খালি পেটে সেবন করুন।",
                    "খাওয়ার পরপরই শুয়ে পড়বেন না, অন্তত ২ ঘণ্টা পর ঘুমান।",
                    "তেল-মশলাযুক্ত খাবার কমিয়ে প্রচুর পানি পান করুন।"
                ),
                color = CyberAmber
            )
        }

        item {
            PreventionGuideCard(
                title = "ডেঙ্গু ও সিজনাল রোগ প্রতিরোধ",
                points = listOf(
                    "জমে থাকা পরিষ্কার পানি অপসারণ করুন এবং দিনেও মশারি বা রিপেলেন্ট ব্যবহার করুন।",
                    "জ্বর হলে প্যারাসিটামল ছাড়া অন্য ব্যথানাশক (যেমন অ্যাসপিরিন, ডাইক্লোফেনাক) সেবন সম্পূর্ণ নিষিদ্ধ।"
                ),
                color = CyberPink
            )
        }

        item {
            PreventionGuideCard(
                title = "উচ্চ রক্তচাপ ও হার্ট কেয়ার",
                points = listOf(
                    "কাঁচা লবণ পরিহার করুন এবং চিকিৎসকের প্রেসক্রিপশনের প্রেশারের ঔষধ প্রতিদিন নির্দিষ্ট সময়ে গ্রহণ করুন।",
                    "প্রতিদিন অন্তত ৩০ মিনিট দ্রুত হাঁটার অভ্যাস গড়ে তুলুন।"
                ),
                color = CyberEmerald
            )
        }

        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF261214))
                    .padding(10.dp)
            ) {
                Text(
                    text = "⚠️ সতর্কবার্তা: অহন একজন এআই সহযোগী। মারাত্মক শারীরিক অসুস্থতা বা জটিলতায় অবশ্যই একজন রেজিস্টার্ড ডাক্তারের সরাসরি পরামর্শ নিন।",
                    fontSize = 11.sp,
                    color = CyberPink
                )
            }
        }
    }
}

@Composable
fun PreventionGuideCard(
    title: String,
    points: List<String>,
    color: Color
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(color)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = color
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            points.forEach { pt ->
                Row(modifier = Modifier.padding(vertical = 2.dp)) {
                    Text(text = "• ", color = color, fontSize = 13.sp)
                    Text(
                        text = pt,
                        fontSize = 12.sp,
                        color = CyberTextPrimary,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

@Composable
fun AddMedicineDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, dosage: String, hour: Int, minute: Int, meal: String, category: String, notes: String) -> Unit
) {
    var medName by remember { mutableStateOf("") }
    var dosage by remember { mutableStateOf("১টি") }
    var hourText by remember { mutableStateOf("08") }
    var minuteText by remember { mutableStateOf("00") }
    var mealTiming by remember { mutableStateOf("খাওয়ার পরে") }
    var category by remember { mutableStateOf("ট্যাবলেট") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CyberDarkNavy,
        title = {
            Text(
                text = "💊 নতুন ঔষধের রিমাইন্ডার",
                color = CyberCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = medName,
                    onValueChange = { medName = it },
                    label = { Text("ঔষধের নাম (যেমন: Napa Extra, Seclo)") },
                    modifier = Modifier.fillMaxWidth().testTag("add_med_name_field"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = CyberCardBorder,
                        focusedTextColor = CyberTextPrimary,
                        unfocusedTextColor = CyberTextPrimary
                    )
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = dosage,
                        onValueChange = { dosage = it },
                        label = { Text("মাত্রা (১টি / ২ চামচ)") },
                        modifier = Modifier.weight(1f).testTag("add_med_dosage_field"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = CyberCardBorder,
                            focusedTextColor = CyberTextPrimary,
                            unfocusedTextColor = CyberTextPrimary
                        )
                    )

                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("ধরণ") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = CyberCardBorder,
                            focusedTextColor = CyberTextPrimary,
                            unfocusedTextColor = CyberTextPrimary
                        )
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = hourText,
                        onValueChange = { hourText = it },
                        label = { Text("ঘণ্টা (০-২৩)") },
                        modifier = Modifier.weight(1f).testTag("add_med_hour_field"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = CyberCardBorder,
                            focusedTextColor = CyberTextPrimary,
                            unfocusedTextColor = CyberTextPrimary
                        )
                    )

                    OutlinedTextField(
                        value = minuteText,
                        onValueChange = { minuteText = it },
                        label = { Text("মিনিট (০-৫৯)") },
                        modifier = Modifier.weight(1f).testTag("add_med_minute_field"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = CyberCardBorder,
                            focusedTextColor = CyberTextPrimary,
                            unfocusedTextColor = CyberTextPrimary
                        )
                    )
                }

                // Meal Timing Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val timings = listOf("খাওয়ার পরে", "খাওয়ার আগে")
                    timings.forEach { t ->
                        val isSel = mealTiming == t
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) CyberCyan else CyberCard)
                                .clickable { mealTiming = t }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = t,
                                color = if (isSel) CyberDarkNavy else CyberTextPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("অতিরিক্ত নোট (ঐচ্ছিক)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = CyberCardBorder,
                        focusedTextColor = CyberTextPrimary,
                        unfocusedTextColor = CyberTextPrimary
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (medName.isNotBlank()) {
                        val h = hourText.toIntOrNull()?.coerceIn(0, 23) ?: 8
                        val m = minuteText.toIntOrNull()?.coerceIn(0, 59) ?: 0
                        onConfirm(medName, dosage, h, m, mealTiming, category, notes)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                modifier = Modifier.testTag("dialog_save_med_btn")
            ) {
                Text("সেভ করুন", color = CyberDarkNavy, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল", color = CyberTextSecondary)
            }
        }
    )
}
